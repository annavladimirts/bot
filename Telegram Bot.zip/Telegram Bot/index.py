import random
import telebot
from mysql.connector import MySQLConnection, Error
from python_mysql_dbconfig import read_db_config

bot = telebot.TeleBot('1394890274:AAHsF0vqpb2mTE4GDdfFquBAgjCtTb4olYs')
keyboard1 = telebot.types.ReplyKeyboardMarkup(True)
keyboard1.row('Начать')


users = {}
@bot.message_handler(commands=['start', 'go'])
def start_message(message):
        chat_id = message.chat.id
        text = message.text
        msg = bot.send_message(chat_id, 'Здравствуйте, ' + message.from_user.first_name + "! Выберите 'Жанр'!", reply_markup=keyboard1)
        isRunning = True

@bot.message_handler(content_types=['text'])
def send_text(message):
    if message.text.lower() == 'начать':
        bot.send_message(message.chat.id, 'Здравствуйте, ' + message.from_user.first_name + "!")

        markup = telebot.types.InlineKeyboardMarkup()
        button1 = telebot.types.InlineKeyboardButton(text='Антиутопия', callback_data='Антиутопия')
        button2 = telebot.types.InlineKeyboardButton(text='Сюрреализм', callback_data='Сюрреализм')
        button3 = telebot.types.InlineKeyboardButton(text='Психоделика', callback_data='Психоделика')
        button4 = telebot.types.InlineKeyboardButton(text='Фэнтези', callback_data='Фэнтези')
        button5 = telebot.types.InlineKeyboardButton(text='Фантастика', callback_data='Фантастика')
        button6 = telebot.types.InlineKeyboardButton(text='Детектив', callback_data='Детектив')
        button7 = telebot.types.InlineKeyboardButton(text='Боевик', callback_data='Боевик')
        button8 = telebot.types.InlineKeyboardButton(text='Постапокалипсис', callback_data='Постапокалипсис')
        button9 = telebot.types.InlineKeyboardButton(text='Хоррор', callback_data='Хоррор')
        button10 = telebot.types.InlineKeyboardButton(text='Постмодернизм', callback_data='Постмодернизм')
        button11 = telebot.types.InlineKeyboardButton(text='Мистика', callback_data='Мистика')

        markup.add(button1)
        markup.add(button2)
        markup.add(button3)
        markup.add(button4)
        markup.add(button5)
        markup.add(button6)
        markup.add(button7)
        markup.add(button8)
        markup.add(button9)
        markup.add(button10)
        markup.add(button11)

        bot.send_message(chat_id=message.chat.id, text='Выберите жанр книги', reply_markup=markup)
    else:
        bot.send_message(message.chat.id, 'Я Вас не понял...')
        bot.send_sticker(message.chat.id, 'CAACAgIAAxkBAANVX2hqJeEftm04pETGatUCvQFBy5IAAtgDAAL6n_EYrJvaUbmzIOEbBA')

@bot.callback_query_handler(func=lambda call: True)
def query_handler(call):
    if call.data == 'Антиутопия':
        message = call.from_user.id
        book = "Антиутопия"
        bot.send_message(call.from_user.id, showBook(book, message))
    if call.data == 'Сюрреализм':
        message = call.from_user.id
        book = "Сюрреализм"
        bot.send_message(call.from_user.id, showBook(book, message))
    if call.data == 'Психоделика':
        message = call.from_user.id
        book = "Психоделика"
        bot.send_message(call.from_user.id, showBook(book, message))
    if call.data == 'Фэнтези':
        message = call.from_user.id
        book = "Фэнтези"
        bot.send_message(call.from_user.id, showBook(book, message))
    if call.data == 'Фантастика':
        message = call.from_user.id
        book = "Фантастика"
        bot.send_message(call.from_user.id, showBook(book, message))
    if call.data == 'Детектив':
        message = call.from_user.id
        book = "Детектив"
        bot.send_message(call.from_user.id, showBook(book, message))
    if call.data == 'Боевик':
        message = call.from_user.id
        book = "Боевик"
        bot.send_message(call.from_user.id, showBook(book, message))
    if call.data == 'Постапокалипсис':
        message = call.from_user.id
        book = "Постапокалипсис"
        bot.send_message(call.from_user.id, showBook(book, message))
    if call.data == 'Хоррор':
        message = call.from_user.id
        book = "Хоррор"
        bot.send_message(call.from_user.id, showBook(book, message))
    if call.data == 'Постмодернизм':
        message = call.from_user.id
        book = "Постмодернизм"
        bot.send_message(call.from_user.id, showBook(book, message))
    if call.data == 'Мистика':
        message = call.from_user.id
        book = "Мистика"
        bot.send_message(call.from_user.id, showBook(book, message))


def showBook(book, message):
    dbconfig = read_db_config()
    conn = MySQLConnection(**dbconfig)
    query = "SELECT * FROM book WHERE Genre = '" + book + "'"
    cursor = conn.cursor()
    cursor.execute(query)

    f = []
    for tir in cursor:
        f.append(tir)
    s = random.choice(f)

    chat_id = message
    return "Автор: " + str(s[1]) +"\nНазвание: " + s[2] + "\nЖанр: " + str(s[3]) + "\nСтрана: " + str(s[4]) + "\nГод: " + str(s[5])



@bot.message_handler(content_types=['sticker'])
def sticker_id(message):
    print(message)

bot.polling()
